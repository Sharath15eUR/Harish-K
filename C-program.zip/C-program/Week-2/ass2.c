// Online C compiler to run C program online
#include <stdio.h>
#include <stdlib.h>

struct node{
    struct node* prev;
    int data;
    struct node* next;
};

int main() {
    //creating doubly linked list
    int n;
    char c;
    struct node* temp;
    struct node* prev;
    struct node* current;
    struct node* last;
    printf("Enter the value of n: ");
    scanf("%d", &n);
    struct node* head = (struct node*)malloc(sizeof(struct node));
    temp=head;
    for(int i=0; i<n; i++){
        struct node* next = (struct node*)malloc(sizeof(struct node));
        scanf(" %c", &c);
        if(i==0){
            temp->data=c;
            temp->next=next;
            temp->prev=NULL;
            prev=temp;
            temp=next;
        }
        else if(i==n-1){
            free(next);
            last=temp;
            temp->data=c;
            temp->prev=prev;
            temp->next=NULL;
        }
        else{
            temp->data=c;
            temp->prev=prev;
            temp->next=next;
            prev=temp;
            temp=next;
        }

    }
    //rotating the linked list
    int a;
    printf("Enter the value of rotation: ");
    scanf("%d", &a);
    for(int i=0; i<=a; i++){
        head->prev=last;
        last->next=head;
        head=last;
        last=head->prev;
        last->next=NULL;
        head->prev=NULL;
    }
    current=head;
    while(current!=NULL){
        printf("%c ",current->data);
        current=current->next;
    }
    return 0;
}