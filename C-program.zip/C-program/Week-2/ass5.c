#include<stdio.h>
#include<stdlib.h>
#define max_size 100

typedef struct{
    int top;
    char items[max_size];
}stack;

void push(stack* s, char c){
    if(s->top==max_size-1){
        printf("Stack is full");
        return;
    }
    s->items[++s->top]=c;
}

void pop(stack* s){
    if(s->top==-1){
        printf("Stack is empty");
        return;
    }
    --s->top;
}

void display(stack* s){
    if(s->top==-1){
        printf("Stack is empty");
        return;
    }
    int n=s->top;
    for(int i=n; i>=0; i--){
        printf("%c", s->items[i]);
    }
}

void main(){
    stack* s =(stack*)malloc(sizeof(stack));
    s->top=-1;
    char c;
    while(1){
        scanf("%c", &c);
        if(c=='\n')
        break;
        push(s, c);
    }
    display(s);
}