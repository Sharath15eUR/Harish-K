/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#define max_size 10
int queue[max_size];
int front=-1, back=-1;

void enqueue(int item){
    if(back==max_size-1){
        printf("queue is full");
        return;
    }
    if(front==-1){
        front=0;
    }
    back++;
    queue[back]=item;
}

int dequeue(){
   if(front==-1 || front>back){
       printf("Queue is empty");
       return -1;
   }
   int item = queue[front];
   front++;
   return item;
}

void display(){
    if(front==-1){
        printf("Queue is empty");
        return;
    }
    for(int i=front; i<=back; i++){
        printf("%d ", queue[i]);
    }
    printf("\n");
}

void sort(){
    int i, j;
    int n=front+back+1;
    for(i=0; i<n-1; i++){
        for(j=i+1; j<n; j++){
            if(queue[i]>queue[j]){
                queue[i]=queue[i]+queue[j];
                queue[j]=queue[i]-queue[j];
                queue[i]=queue[i]-queue[j];
            }
                
        }
    }
}

int main()
{   int temp;
    int count=0;
    do{
        scanf("%d", &temp);
        enqueue(temp);
    }while(getchar()!='\n');
    sort();
    display();
    return 0;
}
