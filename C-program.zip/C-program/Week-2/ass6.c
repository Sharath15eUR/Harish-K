/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

struct list{
    int data;
    struct list* prev;
    struct list* next;
};

void display(struct list* head){
    do{
        printf("%p %d %p = %p\n", head->prev, head->data, head->next, head);
        head=head->next;
    }while(head!=NULL);
}

void arrange(struct list **ptr, int num){
    struct list* head = *ptr;
    while(1){
        if(head->data>=num){
            struct list* current =(struct list*)malloc(sizeof(struct list));
            current->data=num;
            if(head->prev==NULL){
                current->prev=NULL;
                head->prev=current;
                current->next=head;
                *ptr = current;
            }
            else{
                current->prev=head->prev;
                current->next=head;
                current->prev->next=current;
            }
            return;
        }
        else{
            if(head->next==NULL){
                break;
            }
            head=head->next;
        }
    }
    struct list* current =(struct list*)malloc(sizeof(struct list));
    current->data = num;
    current->prev = head;
    head->next = current;
    current->next = NULL;
}
int main()
{
    //creating a doubly linked list
    struct list* head=(struct list*)malloc(sizeof(struct list));
    struct list **ptr = &head;
    struct list* current;
    struct list* prev = NULL;
    current = head;
    int temp;
    do{
        scanf("%d", &temp);
        current->data = temp;
        struct list* next=(struct list*)malloc(sizeof(struct list));
        current->next=next;
        current->prev=prev;
        prev=current;
        current=next;
    }while(getchar()!='\n');
    prev->next=NULL;
    //adding the number
    printf("Enter the number to be added: ");
    scanf("%d", &temp);
    arrange(ptr, temp);
    display(head);
    
}
