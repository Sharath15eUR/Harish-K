#include <stdio.h>

#define max_size 10
int front = -1;
int back  = -1;
int queue[max_size];

void enqueue(int num){
    if(back==max_size-1){
        printf("Queue is full");
        return;
    }
    if(front==-1){
        front=0;
    }
    back++;
    queue[back]=num;
    
}

void dequeue(){
    if(front==-1 || front>=back){
        printf("Queue is full");
        return;
    }
    printf("Deleting the element: %d\n", queue[front++]);
}

void display(){
    int a;
    a=front;
    if(a==-1){
        printf("Queue is empty");
        return;
    }
    printf("Elements in the queue are: ");
    while(a<=back){
        printf("%d ", queue[a]);
        a++;
    }
    printf("\n");
}

void count(){
    int a, n=0;
    a=front;
    if(a==-1){
        printf("Number of elements in queue: %d\n", n);
        return;
    }
    while(a<=back){
        ++n;
        a++;
    }
    printf("Number of elements in queue: %d\n", n);
}

int main(){
    int temp, n=0;
    //Initialize
    printf("Initialize a queue!\n");
    //check whether empty or not
    if(front==-1){
        printf("Queue is empty\n");
    }
    else{
        printf("Queue is not emmpty\n");
    }
    //counting the elements
    count();
    //adding elements
    printf("Enter the elements: ");
    do{
        scanf("%d", &temp);
        enqueue(temp);
    }while(getchar()!='\n' && n+1<max_size);
    //display
    display();
    //deleting 2 times
    n=2;
    while(n!=0){
        dequeue();
        --n;
    }
    //display 
    display();
    //counting
    count();
    //adding elements
    printf("Enter the elements: ");
    n=0;
    do{
        scanf("%d", &temp);
        enqueue(temp);
        ++n;
    }while(getchar()!='\n' && n+1<max_size);
    //display
    display();
    //count
    count();
}