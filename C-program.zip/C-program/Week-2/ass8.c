#include <stdio.h>

int main(){
    int arr1[10], arr2[10], num, n=0, m=0, flag=0, i, j;
    
    printf("Enter the first value elements: ");
    do{
        scanf("%d", &num);
        arr1[n]=num;
        n++;
    }while(getchar()!='\n' && n+1<10);
    
    printf("Enter the second value elements: ");
    do{
        scanf("%d", &num);
        arr2[n]=num;
        m++;
    }while(getchar()!='\n' && m+1<10);    
    
    for(i=0; i<m; i++){
        for(j=0; j<n; j++){
            if(arr2[i]==arr1[j]){
                flag=1;
                break;
            }
        }
        if(j==n){
            printf("array2 is a subset of array1");
            return 0;
        }
    }
    printf("array2 is not a subseet of array1");
}