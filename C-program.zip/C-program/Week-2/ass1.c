#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node* next;
};

int main(){
    int n, num, i;
    printf("Enter the value of N:");
    scanf("%d", &n);
    //creating Linked List
    struct node* temp;
    struct node* head = (struct node*)malloc(sizeof(struct node));
    temp=head;
    for(i=0; i<n; i++){
        scanf("%d", &num);
        struct node* next=(struct node*)malloc(sizeof(struct node));
        if(i!=n-1){
            temp->data=num;
            temp->next=next;
            temp=next;
        }
        else{
            temp->data=num;
            temp->next=NULL;
            free(next);
        }
    }
    //deleting the duplicated list
    struct node* current;
    current=head;
    temp=current->next;
    while(current!=NULL){
        while(temp!=NULL){
            if(current->data==temp->data){
                current->next=temp->next;
                temp=temp->next;
            }
            else{
                break;
            }
        }
        current=current->next;
    }
    //printing linked list
    current=head;
    while(current!=NULL){
        printf("%d %p\n", current->data, current->next);
        current=current->next;
    }
}
